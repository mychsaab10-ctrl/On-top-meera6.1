package com.meera.ai.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.automation.LocationFlow

/**
 * The "where am I?" answer. Glass card on top of everything, on the SCREEN only.
 * It is never sent to Gemini and disappears by itself after 2 minutes (or with Close).
 * "Open in Maps" hands the coordinates to Google Maps on the phone; Gemini is not involved.
 */
@Composable
fun LocationCardOverlay() {
    val card by Meera.locationCard.collectAsState()
    val c = card ?: return
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars).padding(16.dp), contentAlignment = Alignment.BottomCenter) {
        Column(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp), 1.4f).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("📍 ${c.title}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(c.body, color = Color.White, fontSize = 14.sp)
            Text("Shown on this screen only. Not sent to Gemini.", color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                c.fix?.let { f ->
                    TextButton(onClick = {
                        try {
                            ctx.startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("geo:${f.lat},${f.lon}?q=${f.lat},${f.lon}(You+are+here)"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        } catch (e: Exception) { Meera.toast("No maps app found.") }
                    }) { Text("Open in Maps") }
                }
                TextButton(onClick = { LocationFlow.dismiss() }) { Text("Close") }
            }
        }
    }
}
