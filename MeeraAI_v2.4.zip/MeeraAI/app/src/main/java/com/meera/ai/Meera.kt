package com.meera.ai

import android.app.Application
import android.widget.Toast
import com.meera.ai.ai.Answer
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiClient
import com.meera.ai.ai.GeminiException
import com.meera.ai.ai.Mood
import com.meera.ai.ai.Persona
import com.meera.ai.automation.Actions
import com.meera.ai.automation.LocationCardData
import com.meera.ai.automation.LocationFlow
import com.meera.ai.automation.WhereAmI
import com.meera.ai.automation.Messaging
import com.meera.ai.automation.ScreenControl
import com.meera.ai.data.AppSettings
import com.meera.ai.data.MemoryRepo
import com.meera.ai.aura.AuraController
import com.meera.ai.data.SecureKeyStore
import com.meera.ai.eyes.EyesCmd
import com.meera.ai.eyes.EyesCommands
import com.meera.ai.eyes.EyesController
import com.meera.ai.ui.ChatSession
import com.meera.ai.voice.CallController
import com.meera.ai.voice.TtsEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

/**
 * Result of a tool call. When [ask] is true the action is NOT done yet: Meera must first ask the user
 * (by voice or in chat) and the user answers yes/no ("haan"/"nahi" also work). No popup buttons are involved.
 */
data class ToolOut(val text: String, val ask: Boolean = false) {
    /** What the Gemini Live model receives as the tool result. */
    fun forLive(): String =
        if (ask) {
            "WAITING_FOR_USER_CONFIRMATION. Nothing has been done yet. Ask the user this question in their language, in your own words, then wait: \"$text\" " +
                "When the user answers, call confirm_pending with accepted=true (they said yes) or accepted=false (they said no). Never assume the answer."
        } else text
}

/**
 * A yes/no question that Meera asked the user. [action] executes only after a clear "yes" and returns the result text.
 * [local] = the app handles the answer itself (the "Can I check your location now?" question): Gemini may NOT confirm it.
 */
class Awaiting(val prompt: String, val expiresAt: Long, val local: Boolean = false, val action: () -> String)

/** Tiny service locator (keeps the project easy to read for beginners). */
object Meera {
    lateinit var app: Application; private set
    lateinit var keys: SecureKeyStore; private set
    lateinit var settings: AppSettings; private set
    lateinit var gemini: GeminiClient; private set
    lateinit var memory: MemoryRepo; private set
    lateinit var chat: ChatSession; private set
    lateinit var coding: ChatSession; private set
    lateinit var call: CallController; private set
    lateinit var eyes: EyesController; private set
    lateinit var aura: AuraController; private set

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    /** In-app consent switch for screen control (resets on every app start). */
    val accessGate = MutableStateFlow(false)

    /** Log shown on the Phone Automation screen. */
    val log = MutableStateFlow("")

    /** Avatar mood for Home/Chat: normal | happy | excited | sad | loving | thinking. */
    val mood = MutableStateFlow("normal")

    /** The user's latest sentence (typed or transcribed). Used to verify spoken confirmations. */
    @Volatile var lastUserText: String = ""

    @Volatile var awaiting: Awaiting? = null

    /** Set by MainActivity so contacts permission can be requested the first time a name is used. */
    @Volatile var requestContacts: (() -> Unit)? = null

    /** Set by MainActivity so the CAMERA permission can be requested the first time the user says "open your eyes". */
    @Volatile var requestCamera: (() -> Unit)? = null

    /** Set by MainActivity so the LOCATION permission can be requested the first time the user says "yes" to the location question. */
    @Volatile var requestLocation: (() -> Unit)? = null

    /** The "where am I?" answer shown on screen (address + accuracy). RAM only, cleared after 2 minutes. Never sent anywhere. */
    val locationCard = MutableStateFlow<LocationCardData?>(null)

    val tts: TtsEngine by lazy { TtsEngine(app) }

    fun init(a: Application) {
        app = a
        keys = SecureKeyStore(a)
        settings = AppSettings(a)
        gemini = GeminiClient(keys)
        memory = MemoryRepo(a, scope)
        chat = ChatSession("chat")
        coding = ChatSession("coding")
        call = CallController(a, scope)
        eyes = EyesController(a, scope)
        aura = AuraController(a, scope)
        aura.start()
    }

    fun toast(msg: String) = Toast.makeText(app, msg, Toast.LENGTH_LONG).show()

    fun setMood(m: String) { mood.value = m }

    // ───────────── conversational confirmation (replaces popups) ─────────────

    /** Remember what to do after the user says yes, and return the question to ask. */
    fun confirmThen(prompt: String, local: Boolean = false, run: () -> String): ToolOut {
        awaiting = Awaiting(prompt, System.currentTimeMillis() + 120_000, local, run)
        return ToolOut(prompt, ask = true)
    }

    /**
     * "Where am I?" (Roman Urdu / English / Urdu script) is recognized HERE, by the app. Returns the yes/no question to show
     * and speak ("Can I check your location now? (yes / no)"), or null if [text] is something else. Nothing is read yet:
     * the location is read only after the user's own "yes" (see [LocationFlow]). Gemini is never involved.
     */
    fun askWhereAmI(text: String): ToolOut? = if (WhereAmI.match(text)) LocationFlow.ask() else null

    /** True while the app waits for the user's yes/no to the location question. */
    fun waitingForLocationAnswer(): Boolean {
        val w = awaiting ?: return false
        return w.local && System.currentTimeMillis() <= w.expiresAt
    }

    /**
     * Chat and fallback-voice call this with every user sentence BEFORE sending it to Gemini.
     * Returns the result text if the sentence answered a pending question, otherwise null.
     */
    fun interceptAnswer(text: String): String? {
        val w = awaiting ?: return null
        if (System.currentTimeMillis() > w.expiresAt) { awaiting = null; return null }
        return when (Answer.parse(text)) {
            Answer.YES -> { awaiting = null; w.action() }
            Answer.NO -> { awaiting = null; "Okay, cancelled. I did nothing." }
            Answer.UNSURE -> { awaiting = null; null }
        }
    }

    private fun confirmPending(args: JSONObject): ToolOut {
        val w = awaiting ?: return ToolOut("Nothing is waiting for confirmation.")
        // The location question is answered by the app itself, from the user's own words. Gemini can never confirm it.
        if (w.local) return ToolOut("The app handles this question itself. Do nothing and do not mention the user's location.")
        if (System.currentTimeMillis() > w.expiresAt) { awaiting = null; return ToolOut("That question expired. Ask again if still needed.") }
        val accepted = args.optBoolean("accepted", false)
        val said = Answer.parse(lastUserText)
        if (accepted && said != Answer.YES) {
            return ToolOut("The user has NOT clearly said yes. Do nothing. Ask again and wait for a clear 'yes' (or 'haan').")
        }
        awaiting = null
        return if (!accepted || said == Answer.NO) ToolOut("Cancelled. Nothing was done.") else ToolOut(w.action())
    }

    // ───────────── tools coming from Gemini ─────────────

    suspend fun handleCall(name: String, args: JSONObject): ToolOut = when (name) {
        "remember" -> remember(args)
        "forget" -> forget(args)
        "phone_action" -> phone(args)
        "send_message" -> Messaging.request(args)
        "confirm_pending" -> confirmPending(args)
        "screen_action" -> ScreenControl.run(args).also { log.value = it.text }
        "open_eyes" -> eyesTool(EyesCmd.OPEN)
        "close_eyes" -> eyesTool(EyesCmd.CLOSE)
        else -> ToolOut("Unknown tool: $name")
    }

    /**
     * Live call tools open_eyes / close_eyes. Like confirm_pending, the app checks the USER's last words itself:
     * the camera changes only if they really were the command. Gemini alone can never open the camera.
     */
    private fun eyesTool(want: EyesCmd): ToolOut {
        val said = EyesCommands.match(lastUserText)
        if (said != want) {
            val w = if (want == EyesCmd.OPEN) "open" else "close"
            return ToolOut(
                "REFUSED: the user's last words were not an explicit command to $w the eyes. The camera was NOT changed. " +
                    "Do not claim it was, and do not try again unless the user clearly commands it."
            )
        }
        val msg = eyes.runCommand(want)
        return if (want == EyesCmd.OPEN && eyes.isOpen.value) ToolOut("$msg ${eyes.liveHint()}") else ToolOut(msg)
    }

    private fun remember(args: JSONObject): ToolOut {
        val fact = args.optString("fact").trim()
        if (fact.isBlank()) return ToolOut("Nothing to remember.")
        // The user asked for it, so normal facts are saved right away. Sensitive-looking ones still need a clear yes.
        if (MemoryRepo.looksSensitive(fact)) {
            return confirmThen("This looks sensitive (password, number or ID). Do you still want me to remember: \"$fact\"? (yes / no)") {
                memory.add("fact", fact)
                "Okay, saved to memory."
            }
        }
        if (!memory.isDuplicate(fact)) memory.add("fact", fact)
        return ToolOut("Saved to memory: \"$fact\".")
    }

    private fun forget(args: JSONObject): ToolOut {
        val about = args.optString("about").trim().lowercase()
        if (about.length < 3) return ToolOut("Tell me what to forget.")
        val hits = memory.items.value.filter { it.text.lowercase().contains(about) }.take(10)
        if (hits.isEmpty()) return ToolOut("I found no saved memory about \"$about\".")
        return confirmThen("Delete ${hits.size} saved memor${if (hits.size == 1) "y" else "ies"} about \"$about\"? (yes / no)") {
            hits.forEach { memory.delete(it.id) }
            "Deleted ${hits.size} memor${if (hits.size == 1) "y" else "ies"} about \"$about\"."
        }
    }

    private fun phone(args: JSONObject): ToolOut {
        val act = args.optString("action")
        if (Actions.needsConfirm(act)) {
            return confirmThen(Actions.describe(args)) {
                val r = Actions.run(app, args)
                log.value = r
                r
            }
        }
        val r = Actions.run(app, args)
        log.value = r
        return ToolOut(r)
    }

    /** Used by the Phone Automation screen: natural-language command -> tool calls. */
    suspend fun command(text: String): String {
        lastUserText = text
        interceptAnswer(text)?.let { return it }
        askWhereAmI(text)?.let { return it.text }
        val s = settings
        return try {
            val r = gemini.generate(
                s.model, Persona.system("chat"), listOf(ChatMsg("user", text)),
                0.2, tools = Persona.tools
            )
            if (r.calls.isEmpty()) {
                Mood.strip(r.text).ifBlank { "I did not find an action to run." }
            } else {
                val sb = StringBuilder()
                for (c in r.calls) {
                    if (sb.isNotEmpty()) sb.append("\n")
                    sb.append(handleCall(c.name, c.args).text)
                }
                sb.toString()
            }
        } catch (e: GeminiException) {
            e.message ?: "Error"
        }
    }
}
