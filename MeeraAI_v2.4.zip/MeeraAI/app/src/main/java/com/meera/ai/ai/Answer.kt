package com.meera.ai.ai

/** Understands a short spoken/typed yes/no answer (Roman Urdu, Urdu script, English). */
enum class Answer {
    YES, NO, UNSURE;

    companion object {
        private val yes = setOf(
            "haan", "han", "haa", "ha", "hn", "ji", "jee", "haanji", "hanji", "yes", "yeah", "yep", "yup", "ok", "okay",
            "sure", "theek", "thik", "sahi", "zaroor", "bilkul", "kardo", "karo", "bhejo", "bhej", "save", "confirm", "send",
            "acha", "accha", "ہاں", "جی", "ٹھیک", "صحیح", "بھیجو", "کرو"
        )
        private val no = setOf(
            "nahi", "nahin", "no", "nope", "mat", "cancel", "ruko", "ruk", "rukko", "stop", "dont", "don't", "galat", "nako",
            "نہیں", "نہ", "مت", "رکو"
        )

        fun parse(text: String): Answer {
            val t = text.lowercase().replace(Regex("[^\\p{L}\\p{M}\\p{N}' ]"), " ")
            val words = t.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (words.isEmpty() || words.size > 8) return UNSURE
            if (words.any { it in no }) return NO
            if (words.any { it in yes }) return YES
            if (t.contains("kar do") || t.contains("kar de") || t.contains("bhej do") || t.contains("yaad rakh")) return YES
            return UNSURE
        }
    }
}
