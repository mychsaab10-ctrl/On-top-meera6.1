package com.meera.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.meera.ai.automation.MeeraAccessibilityService

@Composable
fun PermissionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) } // bump to re-read status
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val contactsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    fun open(action: String) = ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    val mic = granted(Manifest.permission.RECORD_AUDIO)
    val contacts = granted(Manifest.permission.READ_CONTACTS)
    val camera = granted(Manifest.permission.CAMERA)
    val location = granted(Manifest.permission.ACCESS_FINE_LOCATION) || granted(Manifest.permission.ACCESS_COARSE_LOCATION)
    val overlay = Settings.canDrawOverlays(ctx)
    val notif = Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)
    val listener = NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    val a11y = MeeraAccessibilityService.isEnabled()
    tick.let { }

    SubScreen("Permissions & Privacy", onBack) {
        Text("Meera asks only for the permissions a feature needs. Nothing turns on by itself.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        @Composable
        fun row(title: String, desc: String, ok: Boolean, label: String, onClick: () -> Unit) {
            GlowCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(title, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    Chip(if (ok) "ON" else "OFF", ok)
                }
                Text(desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = onClick) { Text(label) }
            }
        }

        row("🎙 Microphone", "Voice call, dictation and voice notes. The mic runs only during a call or dictation.", mic, "Allow") {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        row("📍 Location", "Location is never sent to Gemini. It is read only on the phone, only after you say \"yes\" to \"Can I check your location now?\", and shown on the screen and spoken by the phone only.", location, "Allow") {
            locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
        row("📷 Camera (Meera Eyes)", "Runs only when you say \"Meera open your eyes\" / \"aankhein kholo\" / \"camera on\". It never opens by itself. Nothing is saved or recorded.", camera, "Allow") {
            cameraLauncher.launch(Manifest.permission.CAMERA)
        }
        row("🪟 Display over other apps (Meera Aura)", "Only for the \"Whole phone\" border. If your phone shows \"Feature not available\", turn on Meera in Accessibility instead: the border works from there too. The overlay only draws a line, never blocks touches and records nothing.", overlay, "Open settings") {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        row("👤 Contacts", "Only when you send WhatsApp/SMS by a contact name. Contacts are searched on the phone and are not sent to Gemini.", contacts, "Allow") {
            contactsLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
        row("🔔 Notifications", "Shows the call-in-progress and quick-access notifications.", notif, "Allow") {
            if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        row("📩 Notification access", "Lets Meera read other apps' notifications (optional). They stay in memory only.", listener, "Open settings") {
            open("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
        }
        row("♿ Accessibility service", "For reading the screen, tapping, scrolling, swiping and typing (optional and powerful: turn it on only when you need it).", a11y, "Open settings") {
            open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        }
        row("⚙ App info", "Android's own permission screen (the camera/gallery pickers need no permission).", true, "Open") {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        SectionTitle("Privacy")
        Text(
            "• Your chats go to Google's Gemini API with your own key. Google's privacy policy applies.\n" +
                "• Memory (including automatically saved facts) and your recent chat are stored only on this phone. You can see, edit and delete memories, turn Auto memory off, and clear the chat. The API key is separate and Keystore-encrypted.\n" +
                "• Passwords, OTPs, card and ID numbers are never saved automatically.\n" +
                "• Meera asks you (yes / no) before sending a message, dialing, or tapping the screen.\n" +
                "• Backups are off (allowBackup=false).\n" +
                "• Camera (Meera Eyes): runs only on your command and closes on the close command, the Close/Back button, when the app goes to the background, or after the auto-close timer. Frames go only to Gemini while the eyes are ON; nothing is saved or recorded. A person is only ever labelled \"HUMAN\": no name, no identification, no age, no emotions.\n" +
                "• Location is never sent to Gemini; it is read only on the phone, after your \"yes\", and kept in RAM for 2 minutes at most.\n" +
                "• Notifications and screen text are not saved to disk.",
            fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface
        )
    }
}
