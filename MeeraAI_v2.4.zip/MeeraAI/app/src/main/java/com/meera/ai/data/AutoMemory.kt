package com.meera.ai.data

import com.meera.ai.Meera
import com.meera.ai.ai.ChatMsg
import com.meera.ai.ai.GeminiException
import com.meera.ai.automation.WhereAmI
import com.meera.ai.eyes.EyesCommands
import kotlinx.coroutines.launch
import org.json.JSONException
import org.json.JSONObject

/**
 * "Remember me like ChatGPT": after each thing the user says, a small background request asks Gemini to pull out
 * lasting facts (name, family, friends, work, places, preferences, plans, goals...) and saves the new ones.
 * - Switch: Settings -> Memory -> Auto memory (default ON). Everything is visible / editable / deletable in Memory.
 * - Passwords, OTPs, card or ID numbers are never saved (MemoryRepo.looksSensitive).
 * - Only the user's own sentence is sent, together with a short extraction instruction.
 * - One request at a time; if the user keeps talking, only the newest pending sentence is kept.
 */
object AutoMemory {
    private var busy = false
    private var pending: String? = null

    private const val PROMPT =
        "From the user's message below, extract NEW durable facts about the user that are worth remembering long-term: " +
            "name, age group, family, friends, pets, job/school, city, habits, likes/dislikes, health routines (not diagnoses), plans, goals, important dates. " +
            "Rules: skip questions, commands, small talk, one-off requests, and anything that is only about the weather/time/news. " +
            "NEVER include passwords, PINs, OTPs, card, bank, ID or passport numbers. " +
            "Write each fact as one short English sentence starting with \"User\". " +
            "Return ONLY JSON: {\"facts\":[\"...\"]}. Use an empty list if there is nothing.\n\nMessage: "

    fun consider(text: String) {
        if (!Meera.settings.autoMemory) return
        val t = text.trim()
        if (t.length < 12 || MemoryRepo.looksSensitive(t) || EyesCommands.match(t) != null || WhereAmI.match(t)) return // location questions are never memory material
        if (busy) { pending = t; return }
        busy = true
        Meera.scope.launch {
            try {
                var cur: String? = t
                while (cur != null) {
                    extract(cur)
                    cur = pending
                    pending = null
                }
            } finally {
                busy = false
            }
        }
    }

    private suspend fun extract(t: String) {
        try {
            val r = Meera.gemini.generate(
                Meera.settings.model, null, listOf(ChatMsg("user", PROMPT + t)), 0.2, jsonMode = true, fast = true
            )
            var s = r.text.trim()
            if (s.startsWith("```")) s = s.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val a = s.indexOf('{')
            val b = s.lastIndexOf('}')
            if (a < 0 || b <= a) return
            val arr = JSONObject(s.substring(a, b + 1)).optJSONArray("facts") ?: return
            for (i in 0 until minOf(arr.length(), 5)) {
                val f = arr.optString(i).trim()
                if (f.length < 8 || f.length > 300 || MemoryRepo.looksSensitive(f)) continue
                if (Meera.memory.isDuplicate(f)) continue
                Meera.memory.add("auto", f)
            }
        } catch (e: GeminiException) {
            // no key / server busy: just skip this one
        } catch (e: JSONException) {
        }
    }
}
