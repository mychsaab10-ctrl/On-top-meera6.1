package com.meera.ai.aura

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.SweepGradient
import android.os.SystemClock
import android.view.View
import com.meera.ai.Meera
import kotlin.math.abs
import kotlin.math.sin

/**
 * The Meera Aura border: three glow layers + a thin bright line + travelling "comets", all following the
 * rounded screen outline. Plain Canvas drawing (no blur, no bitmaps) so it stays light. It never takes touches.
 */
class AuraView(ctx: Context) : View(ctx) {
    private val dp = ctx.resources.displayMetrics.density
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val cometPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val path = Path()
    private val rect = RectF()
    private val mtx = Matrix()
    private var perimeter = 1f
    private var shader: SweepGradient? = null
    private var shaderFor: AuraState? = null
    private var amp = 0f
    private var pos = 0f
    private var last = 0L
    private val t0 = SystemClock.uptimeMillis()

    init {
        isClickable = false
        isFocusable = false
        setWillNotDraw(false)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val inset = 1.5f * dp
        val r = 30f * dp
        rect.set(inset, inset, w - inset, h - inset)
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        perimeter = PathMeasure(path, false).length.coerceAtLeast(1f)
        shader = null
    }

    private fun palette(s: AuraState): IntArray = when (s) {
        AuraState.SPEAK -> intArrayOf(0xFF22D3EE.toInt(), 0xFFB388FF.toInt(), 0xFFFF4FA3.toInt())
        AuraState.THINK -> intArrayOf(0xFF8B7CFF.toInt(), 0xFFC084FC.toInt(), 0xFF8B7CFF.toInt())
        else -> intArrayOf(0xFF22D3EE.toInt(), 0xFF5EEAD4.toInt(), 0xFF22D3EE.toInt())
    }

    /** Natural-looking speech envelope, used when there is no real audio level (Android TTS). */
    private fun synth(t: Float): Float {
        val a = abs(sin(t * 5.1f)) * 0.55f + abs(sin(t * 2.3f + 1f)) * 0.35f
        val gap = if (sin(t * 0.9f) > 0.82f) 0.15f else 1f
        return (a * gap + (Math.random().toFloat() * 0.08f)).coerceIn(0f, 1f)
    }

    override fun onDraw(canvas: Canvas) {
        postInvalidateOnAnimation()
        val st = Meera.aura.state.value
        if (st == AuraState.OFF || width == 0 || height == 0) return
        val now = SystemClock.uptimeMillis()
        val t = (now - t0) / 1000f
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceIn(0f, 0.1f)
        last = now

        val target = when (st) {
            AuraState.SPEAK -> if (now - Meera.aura.realAt < 300L) Meera.aura.realLevel else synth(t)
            AuraState.LISTEN -> 0.18f + 0.10f * sin(t * 1.6f)
            else -> 0.22f
        }
        amp += (target - amp) * 0.25f
        val a = (amp * Meera.aura.gain).coerceIn(0f, 1f)

        val cols = palette(st)
        val cx = width / 2f
        val cy = height / 2f
        if (shader == null || shaderFor != st) {
            shader = SweepGradient(cx, cy, intArrayOf(cols[0], cols[1], cols[2], cols[0]), floatArrayOf(0f, 0.33f, 0.66f, 1f))
            shaderFor = st
        }
        val sh = shader ?: return
        mtx.setRotate(t * (if (st == AuraState.SPEAK) 70f else 30f), cx, cy)
        sh.setLocalMatrix(mtx)

        stroke.shader = sh
        stroke.strokeWidth = (14f + a * 26f) * dp
        stroke.alpha = ((0.08f + a * 0.22f) * 255f).toInt()
        canvas.drawPath(path, stroke)
        stroke.strokeWidth = (7f + a * 12f) * dp
        stroke.alpha = ((0.18f + a * 0.32f) * 255f).toInt()
        canvas.drawPath(path, stroke)
        stroke.strokeWidth = (2.2f + a * 2.2f) * dp
        stroke.alpha = 217
        canvas.drawPath(path, stroke)

        val speed = when (st) {
            AuraState.SPEAK -> 160f + a * 260f
            AuraState.THINK -> 220f
            else -> 60f
        } * dp
        pos = (pos + speed * dt) % perimeter

        fun comet(offset: Float, lenDp: Float) {
            val phase = perimeter - ((pos + offset) % perimeter)
            cometPaint.pathEffect = DashPathEffect(floatArrayOf(lenDp * dp, perimeter), phase)
            cometPaint.color = cols[1]
            cometPaint.alpha = 90
            cometPaint.strokeWidth = 8f * dp
            canvas.drawPath(path, cometPaint)
            cometPaint.color = Color.WHITE
            cometPaint.alpha = 240
            cometPaint.strokeWidth = 3f * dp
            canvas.drawPath(path, cometPaint)
        }
        when (st) {
            AuraState.LISTEN -> comet(0f, 22f + 10f * sin(t * 1.6f))
            AuraState.THINK -> { comet(0f, 46f); comet(perimeter / 2f, 46f) }
            else -> { comet(0f, 46f); comet(perimeter / 2f, 26f) }
        }
    }
}
